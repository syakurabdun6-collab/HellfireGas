
package com.hellfiregas;

import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;

public class ModParticles {

    public static final SimpleParticleType DECORATIVE_FLAME =
            FabricParticleTypes.simple();

    public static void initialize() {
        Registry.register(
            BuiltInRegistries.PARTICLE_TYPE,
            Identifier.fromNamespaceAndPath(
                "hellfiregas",
                "decorative_flame"
            ),
            DECORATIVE_FLAME
        );
    }
}
