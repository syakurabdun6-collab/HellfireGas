
package com.hellfiregas;

import java.util.function.Function;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;

import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

public class ModItems {

    public static final Item HELLFIRE_EMBLEM = register(
        "hellfire_emblem",
        Item::new,
        new Item.Properties()
    );

    private static Item register(
        String name,
        Function<Item.Properties, Item> factory,
        Item.Properties properties
    ) {
        ResourceKey<Item> key = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath("hellfiregas", name)
        );

        Item item = factory.apply(properties.setId(key));

        Registry.register(
            BuiltInRegistries.ITEM,
            key,
            item
        );

        return item;
    }

    public static void initialize() {
        CreativeModeTabEvents.modifyOutputEvent(
            CreativeModeTabs.INGREDIENTS
        ).register(entries -> {
            entries.accept(HELLFIRE_EMBLEM);
        });
    }
}
