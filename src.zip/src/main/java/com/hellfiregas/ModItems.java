package com.hellfiregas;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;

public class ModItems {

    public static final Item HELLFIRE_EMBLEM = register("hellfire_emblem");

    public static final ResourceKey<CreativeModeTab> HELLFIRE_TAB_KEY =
        ResourceKey.create(
            BuiltInRegistries.CREATIVE_MODE_TAB.key(),
            Identifier.fromNamespaceAndPath(HellfireGas.MOD_ID, "hellfire_gas")
        );

    public static final CreativeModeTab HELLFIRE_TAB =
        FabricCreativeModeTab.builder()
            .icon(() -> new ItemStack(HELLFIRE_EMBLEM))
            .title(Component.literal("Hellfire Gas"))
            .displayItems((parameters, output) -> {
                output.accept(HELLFIRE_EMBLEM);
            })
            .build();

    private static Item register(String name) {
        ResourceKey<Item> key = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(HellfireGas.MOD_ID, name)
        );

        Item item = new Item(new Item.Properties().setId(key));

        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void initialize() {
        Registry.register(
            BuiltInRegistries.CREATIVE_MODE_TAB,
            HELLFIRE_TAB_KEY,
            HELLFIRE_TAB
        );

        System.out.println("Hellfire Gas Creative Tab berhasil dimuat!");
    }
}