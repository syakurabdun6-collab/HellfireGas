package com.hellfiregas;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;

public class ModItems {

    public static final Item HELLFIRE_EMBLEM = register("hellfire_emblem");

    private static Item register(String name) {
        ResourceKey<Item> key = ResourceKey.create(
            Registries.ITEM,
            Identifier.fromNamespaceAndPath(HellfireGas.MOD_ID, name)
        );

        Item item = new Item(new Item.Properties().setId(key));

        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    public static void initialize() {
        CreativeModeTabEvents.modifyOutputEvent(
            CreativeModeTabs.INGREDIENTS
        ).register(entries -> entries.accept(HELLFIRE_EMBLEM));

        System.out.println("ModItems initialize berjalan!");
    }
}