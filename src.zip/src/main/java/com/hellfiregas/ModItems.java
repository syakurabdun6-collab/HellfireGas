public static void initialize() {
    System.out.println("ModItems initialize berjalan!");

    CreativeModeTabEvents.modifyOutputEvent(
        CreativeModeTabs.INGREDIENTS
    ).register(entries -> entries.accept(HELLFIRE_EMBLEM));
}