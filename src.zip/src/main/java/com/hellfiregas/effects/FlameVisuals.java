package com.hellfiregas.client;

import com.hellfiregas.ModItems;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.client.Minecraft;

public class FlameVisuals {

    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.level == null) {
                return;
            }

            boolean holdingEmblem =
                client.player.getMainHandItem().is(ModItems.HELLFIRE_EMBLEM)
                || client.player.getOffhandItem().is(ModItems.HELLFIRE_EMBLEM);

            if (!holdingEmblem) {
                return;
            }

            double x = client.player.getX();
            double y = client.player.getY() + 1.0;
            double z = client.player.getZ();

            client.level.addParticle(
                ParticleTypes.FLAME,
                x + (Math.random() - 0.5) * 0.6,
                y + Math.random() * 0.5,
                z + (Math.random() - 0.5) * 0.6,
                0.0, 0.02, 0.0
            );
        });

        System.out.println("Hellfire decorative aura aktif!");
    }
}