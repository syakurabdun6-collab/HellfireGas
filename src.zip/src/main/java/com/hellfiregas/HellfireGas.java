package com.hellfiregas.client;

import com.hellfiregas.HellfireGas;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.client.particle.FlameParticle;

public class HellfireGasClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        ParticleFactoryRegistry.getInstance().register(
            HellfireGas.DECORATIVE_FLAME,
            FlameParticle.Provider::new
        );
    }
}