package com.hellfiregas.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleTypes;

/** Client-side visual state for the G-key transformation toggle. */
public final class FlameVisuals {
    private static boolean transformed;

    private FlameVisuals() {}

    public static boolean isTransformed() {
        return transformed;
    }

    public static void toggle(Minecraft client) {
        transformed = !transformed;
        if (client.player != null) {
            client.player.displayClientMessage(
                    net.minecraft.network.chat.Component.literal(
                            transformed ? "Hellfire: TRANSFORMASI AKTIF" : "Hellfire: TRANSFORMASI NONAKTIF"),
                    true);
        }
    }

    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!transformed || client.player == null || client.level == null) return;

            // Multi-height decorative flame halo. Cosmetic only.
            double angle = client.player.tickCount * 0.19;
            for (int i = 0; i < 8; i++) {
                double a = angle + (Math.PI * 2.0 * i / 8.0);
                double radius = 0.48 + (i % 2) * 0.08;
                double x = client.player.getX() + Math.cos(a) * radius;
                double z = client.player.getZ() + Math.sin(a) * radius;
                double y = client.player.getY() + 0.18 + (i % 4) * 0.42;

                client.level.addParticle(ParticleTypes.FLAME, x, y, z,
                        Math.cos(a) * 0.008, 0.018, Math.sin(a) * 0.008);

                if (i % 2 == 0) {
                    client.level.addParticle(ParticleTypes.SMOKE, x, y + 0.08, z,
                            0.0, 0.012, 0.0);
                }
            }
        });
    }
}
