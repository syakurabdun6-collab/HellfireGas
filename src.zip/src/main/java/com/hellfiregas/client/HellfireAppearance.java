package com.hellfiregas.client;

import net.minecraft.resources.Identifier;

/**
 * Stage 4 appearance manifest.
 *
 * Keeps the client-side cosmetic resource locations in one place so the
 * player render-layer integration can consume them without hard-coded paths.
 * This class does not alter gameplay or equipment.
 */
public final class HellfireAppearance {
    public static final Identifier ARMOR_TEXTURE =
            Identifier.fromNamespaceAndPath("hellfiregas", "textures/entity/hellfire_armor_overlay.png");
    public static final Identifier SKULL_TEXTURE =
            Identifier.fromNamespaceAndPath("hellfiregas", "textures/entity/hellfire_skull.png");

    private HellfireAppearance() {}

    public static boolean shouldRender() {
        return FlameVisuals.isTransformed();
    }
}
