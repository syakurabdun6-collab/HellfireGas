package com.hellfiregas.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

/**
 * Cosmetic Ghost Rider-style layer for the local player's avatar.
 * Uses the animated vanilla player model parts, so the overlay follows
 * the normal pose for walking, sprinting, crouching and swimming.
 */
public final class HellfirePlayerRenderLayer
        extends RenderLayer<AvatarRenderState, PlayerModel> {

    public HellfirePlayerRenderLayer(
            RenderLayerParent<AvatarRenderState, PlayerModel> parent) {
        super(parent);
    }

    @Override
    public void submit(
            PoseStack poseStack,
            SubmitNodeCollector submitNodeCollector,
            int lightCoords,
            AvatarRenderState state,
            float yRot,
            float xRot) {

        if (!HellfireAppearance.shouldRender() || state.isSpectator) {
            return;
        }

        // The G toggle is currently local-only; do not transform every other avatar.
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.player.getId() != state.id) {
            return;
        }

        PlayerModel model = getParentModel();

        // Skull replaces the visible head surface.
        submitPart(model, model.head, HellfireAppearance.SKULL_TEXTURE,
                poseStack, submitNodeCollector, lightCoords);

        // Transparent armor texture is placed on the vanilla outer body parts.
        // These parts inherit the player's current animation and slim/classic arm model.
        Identifier armor = HellfireAppearance.ARMOR_TEXTURE;
        submitPart(model, model.jacket, armor, poseStack, submitNodeCollector, lightCoords);
        submitPart(model, model.leftSleeve, armor, poseStack, submitNodeCollector, lightCoords);
        submitPart(model, model.rightSleeve, armor, poseStack, submitNodeCollector, lightCoords);
        submitPart(model, model.leftPants, armor, poseStack, submitNodeCollector, lightCoords);
        submitPart(model, model.rightPants, armor, poseStack, submitNodeCollector, lightCoords);
    }

    private static void submitPart(
            PlayerModel model,
            ModelPart part,
            Identifier texture,
            PoseStack poseStack,
            SubmitNodeCollector collector,
            int lightCoords) {
        if (part == null || !part.visible) {
            return;
        }
        collector.submitModelPart(
                part,
                poseStack,
                model.renderType(texture),
                lightCoords,
                OverlayTexture.NO_OVERLAY,
                null);
    }
}
