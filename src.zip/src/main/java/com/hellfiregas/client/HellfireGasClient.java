package com.hellfiregas.client;

import net.fabricmc.api.ClientModInitializer;

public class HellfireGasClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        FlameVisuals.initialize();

        System.out.println("Hellfire Gas Client berhasil dimuat!");
    }
}