
package com.hellfiregas.client;

import net.fabricmc.api.ClientModInitializer;

public class HellfireGasClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        System.out.println("Hellfire Gas Client Loaded!");
    }
}
