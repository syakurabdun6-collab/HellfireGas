
package com.hellfiregas.client;

import com.hellfiregas.ModParticles;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.particle.v1.ParticleProviderRegistry;
import net.minecraft.client.particle.EndRodParticle;

public class HellfireGasClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

        ParticleProviderRegistry.getInstance().register(
            ModParticles.DECORATIVE_FLAME,
            EndRodParticle.Provider::new
        );

        System.out.println("Hellfire Gas Particle Loaded!");
    }
}
