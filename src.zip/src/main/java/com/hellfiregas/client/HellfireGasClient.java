package com.hellfiregas.client;

import com.hellfiregas.ModItems;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.core.particles.ParticleTypes;

public class FlameVisuals {
    public static void initialize() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.level == null) return;

            boolean holdingChainsaw =
                client.player.getMainHandItem().is(ModItems.HELLFIRE_EMBLEM)
                || client.player.getOffhandItem().is(ModItems.HELLFIRE_EMBLEM);

            if (!holdingChainsaw) return;

            double x = client.player.getX();
            double y = client.player.getY() + 1.0;
            double z = client.player.getZ();

            // Asap gas ungu
            client.level.addParticle(
                ParticleTypes.DRAGON_BREATH,
                x + 0.35 + (Math.random() - 0.5) * 0.35,
                y + (Math.random() - 0.5) * 0.4,
                z + (Math.random() - 0.5) * 0.35,
                0.0, 0.025, 0.0
            );

            // Bara api
            client.level.addParticle(
                ParticleTypes.FLAME,
                x + 0.35 + (Math.random() - 0.5) * 0.3,
                y + (Math.random() - 0.5) * 0.3,
                z + (Math.random() - 0.5) * 0.3,
                0.0, 0.015, 0.0
            );
        });

        System.out.println("Hellfire Gas aura aktif!");
    }
}