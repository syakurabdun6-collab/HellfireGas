package com.hellfiregas.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import net.minecraft.client.renderer.entity.player.AvatarRenderer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public final class HellfireGasClient implements ClientModInitializer {
    private static final KeyMapping.Category HELLFIRE_CATEGORY = KeyMapping.Category.register(
            Identifier.fromNamespaceAndPath("hellfiregas", "controls"));

    private static final KeyMapping TRANSFORM_KEY = KeyMappingHelper.registerKeyMapping(
            new KeyMapping("key.hellfiregas.transform",
                    InputConstants.Type.KEYSYM,
                    InputConstants.KEY_G,
                    HELLFIRE_CATEGORY));

    @Override
    public void onInitializeClient() {
        FlameVisuals.initialize();

        LivingEntityRenderLayerRegistrationCallback.EVENT.register(
                (entityType, entityRenderer, registrationHelper, context) -> {
                    if (entityRenderer instanceof AvatarRenderer<?> avatarRenderer) {
                        @SuppressWarnings("unchecked")
                        RenderLayerParent<AvatarRenderState, PlayerModel> parent =
                                (RenderLayerParent<AvatarRenderState, PlayerModel>) avatarRenderer;
                        registrationHelper.register(new HellfirePlayerRenderLayer(parent));
                    }
                });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (TRANSFORM_KEY.consumeClick()) {
                FlameVisuals.toggle(client);
            }
        });
    }
}
